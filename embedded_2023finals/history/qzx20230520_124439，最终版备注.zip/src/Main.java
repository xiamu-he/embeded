import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static int N;
    public static int M;
    public static int T;
    public static int P;
    public static int D;
    public static ArrayList<int[]> addSide = new ArrayList<>();//记录所加边的起止节点
    public static ArrayList<Integer>[] graphList;//记录无重复节点的邻接表
    public static Passage[][] graph;//所有边的邻接矩阵
    public static ArrayList<Side> sides = new ArrayList<>();//所有边
    public static int[][] sideArray;//边的初始化数组
    public static Business[] businessTotal;//总业务
    static boolean[] visited;
    static int[] pre;

    static ArrayList<Track>[][] minTrackWithT;//节点间的所有最短Track

    static ArrayList<Map.Entry<String, ArrayList<Integer>>> entryList;//起止点-businessId键值对

    static int totalAddSideCost;
    static int totalAmplifierCost;
    static int totalEdgeCost;
    static int totalCost;
    static final int ADD_SIDE_COST = 1000000;
    static final int AMPLIFIER_COST = 100;
    static final int EDGE_COST = 1;

    static int THROUGH_EDGE_COST = 100000;

    static int notProcessNum;

    static int sameBussPrec = 10;//相同业务数的比例

    public static void main(String[] args) throws IOException {
        init();

        int upPNum = 0;
        //判断相同业务/通道数之和
        for(Map.Entry<String, ArrayList<Integer>> entry : entryList){
            if(entry.getValue().size() >= P)upPNum+=entry.getValue().size()/P;
        }

        //第一阶段的策略，取决于upPNum的数量
        if(upPNum >= entryList.size() / sameBussPrec)oneStageUp();
        else oneStageDown();

        //第二阶段
        twoStage();

        output();
        outCost();
    }

    public static void oneStageUp(){
        for(int p = 0;p<P;p++){
            for(int i = 0;i<entryList.size();i++){
                int p1 = p;
                Track minTrack = null;
                for(int j = 0;j<entryList.get(i).getValue().size();j++){
                    int t = entryList.get(i).getValue().get(j);
                    if(!businessTotal[t].isProcess ){
                        int startNode = businessTotal[t].startNode;
                        int endNode = businessTotal[t].endNode;
                        //获得业务在通道p中不需要加边的最短路径
                        if(j % (P-p) == 0){
                            p1 = p;
                            minTrack = getPath1(startNode, endNode, p);
                            if(!minTrack.trackList.isEmpty()){
                                //根据路径处理对应业务
                                processBus(t,minTrack);
                            }else minTrack = null;
                        }
                        else if(minTrack != null){
                            p1++;
                            if(p1<P){
                                minTrack.p = p1;
                                if(minTrack.trackList.get(0) != startNode){
                                    Collections.reverse(minTrack.trackList);
                                }
                                processBus(t,minTrack);
                            }
                        }
                    }
                }
            }
        }
    }

    public static void oneStageDown(){
        ArrayList<Integer> businessList1 = sortBusiness1();
        for(int p = 0;p<P;p++){
            //businessList1 = sortBusiness3(p);
            for(int i = 0;i<T;i++){
                int t = businessList1.get(i);
                if(!businessTotal[t].isProcess){
                    int startNode = businessTotal[t].startNode;
                    int endNode = businessTotal[t].endNode;
                    //获得业务在通道p中不需要加边的最短路径
                    Track minTrack = getPath1(startNode, endNode, p);
//                    if(minTrack.trackList.isEmpty()){
//                        minTrack = getMinPathWithP(startNode,endNode,p);
//                    }
                    if(!minTrack.trackList.isEmpty()){
                        //根据路径处理对应业务
                        processBus(t,minTrack);
                    }
                }
            }
        }
    }

    /*
     * 第2阶段
     * 对没有处理的业务进行遍历
     *  找最小成本的路径
     *  经过一条边时，根据 剩余业务数 和 该passage在p下可以通过的边的数量 对 经过一条边的成本进行动态更新
     * */
    public static void twoStage(){
        ArrayList<Integer> businessList1 = sortBusiness1();
        for (int i = 0; i < T; i++) {
            int t = businessList1.get(i);
            if(!businessTotal[t].isProcess){
                int startNode = businessTotal[t].startNode;
                int endNode = businessTotal[t].endNode;
                //找不用加边的最短路径
                //Track minTrack = getPath1(startNode, endNode);
                //不存在时加边，从最短路径里找
                //if (minTrack.trackList.isEmpty()) {
                    setThroughEdgeCost();
                    Track minTrack = getMinCostTrack(startNode, endNode);
                    //对路径进行加边
                    addSide(minTrack,t);
                //}


                //根据路径处理业务
                processBus(t,minTrack);
            }
        }
    }

    public static void setThroughEdgeCost(){
        THROUGH_EDGE_COST = (int)(notProcessNum * 1.0 / T * ADD_SIDE_COST);
    }

    private static void outCost() throws IOException {
        for(int i = 0;i<T;i++){
            totalAddSideCost+= businessTotal[i].addSideCost;
            totalAmplifierCost+= businessTotal[i].amplifierCost;
            totalEdgeCost+= businessTotal[i].edgeCost;
        }
        totalCost = totalAddSideCost+totalAmplifierCost+totalEdgeCost;

        BufferedWriter bw = new BufferedWriter(new FileWriter("result.txt",true));
//        bw.write("*******************"+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date())+"*******************");
//        bw.newLine();
        bw.write("totalAddSideCost:"+totalAddSideCost);bw.newLine();
        bw.write("totalAmplifierCost:"+totalAmplifierCost);bw.newLine();
        bw.write("totalEdgeCost:"+totalEdgeCost);bw.newLine();
        bw.write("totalCost:"+totalCost);bw.newLine();
        bw.close();
    }

    //对业务进行排序，按最短轨迹长度降序
    public static ArrayList<Integer> sortBusiness1(){
        ArrayList<Integer> result = new ArrayList<>();
        for(int i = 0;i<T;i++){
            result.add(i);
        }
        result.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                int startNode1 = businessTotal[o1].startNode;
                int startNode2 = businessTotal[o2].startNode;
                int endNode1 = businessTotal[o1].endNode;
                int endNode2 = businessTotal[o2].endNode;

                int flexibility1 = 0;
                int flexibility2 = 0;

                for(int i = 0;i<minTrackWithT[startNode1][endNode1].size();i++){
                    Track track = minTrackWithT[startNode1][endNode1].get(i);
                    flexibility1+= getSidesNum(track) / track.trackList.size();
                }
                for(int i = 0;i<minTrackWithT[startNode2][endNode2].size();i++){
                    Track track = minTrackWithT[startNode2][endNode2].get(i);
                    flexibility2+= getSidesNum(track) / track.trackList.size();
                }
                int num =minTrackWithT[startNode2][endNode2].get(0).trackList.size()
                        - minTrackWithT[startNode1][endNode1].get(0).trackList.size();
//                int num1 = num == 0? minTrackWithT[startNode2][endNode2].get(0).trackList.size()
//                        - minTrackWithT[startNode1][endNode1].get(0).trackList.size() :num;
                int num2 = num == 0 ? flexibility1-flexibility2 : num;
                return num2;
            }
        });
        return result;
    }

    public static ArrayList<Integer> sortBusiness2(){
        ArrayList<Integer> result = new ArrayList<>();
        entryList.sort(new Comparator<Map.Entry<String, ArrayList<Integer>>>() {
            @Override
            public int compare(Map.Entry<String, ArrayList<Integer>> o1, Map.Entry<String, ArrayList<Integer>> o2) {
                int b1 = o1.getValue().get(0);
                int b2 = o2.getValue().get(0);

                int startNode1 = businessTotal[b1].startNode;
                int startNode2 = businessTotal[b2].startNode;
                int endNode1 = businessTotal[b1].endNode;
                int endNode2 = businessTotal[b2].endNode;

                int flexibility1 = 0;
                int flexibility2 = 0;

                for(int i = 0;i<minTrackWithT[startNode1][endNode1].size();i++){
                    Track track = minTrackWithT[startNode1][endNode1].get(i);
                    flexibility1+= getSidesNum(track) / track.trackList.size();
                }
                for(int i = 0;i<minTrackWithT[startNode2][endNode2].size();i++){
                    Track track = minTrackWithT[startNode2][endNode2].get(i);
                    flexibility2+= getSidesNum(track) / track.trackList.size();
                }
                int num1 =minTrackWithT[startNode2][endNode2].get(0).trackList.size()
                        - minTrackWithT[startNode1][endNode1].get(0).trackList.size();
                int num2 = num1 == 0 ?flexibility1-flexibility2 : num1;
                return num2;
            }
        });
        for(Map.Entry<String, ArrayList<Integer>> entry : entryList){
            result.addAll(entry.getValue());
        }
        return result;
    }

    //根据通道，对业务按剩余边数排序
    public static ArrayList<Integer> sortBusiness3(int p){
        ArrayList<Integer> result = new ArrayList<>();
        for(int i = 0;i<T;i++){
            result.add(i);
        }
        result.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                int startNode1 = businessTotal[o1].startNode;
                int startNode2 = businessTotal[o2].startNode;
                int endNode1 = businessTotal[o1].endNode;
                int endNode2 = businessTotal[o2].endNode;

                int flexibility1 = 0;
                int flexibility2 = 0;

                HashSet<Integer> sideSet1 = new HashSet<>();
                HashSet<Integer> sideSet2 = new HashSet<>();
                for(int i = 0;i<minTrackWithT[startNode1][endNode1].size();i++){
                    Track track = minTrackWithT[startNode1][endNode1].get(i);
                    for(int j = 0;j<track.trackList.size()-1;j++){
                        int start = track.trackList.get(j);
                        int end = track.trackList.get(j+1);
                        for(int x = 0;x <graph[start][end].sides.size();x++) {
                            Integer index = graph[start][end].sides.get(x);
                            if(!sides.get(index).isUsed[p])sideSet1.add(index);
                        }
                    }
                }
                for(int i = 0;i<minTrackWithT[startNode2][endNode2].size();i++){
                    Track track = minTrackWithT[startNode2][endNode2].get(i);
                    for(int j = 0;j<track.trackList.size()-1;j++){
                        int start = track.trackList.get(j);
                        int end = track.trackList.get(j+1);
                        for(int x = 0;x <graph[start][end].sides.size();x++) {
                            Integer index = graph[start][end].sides.get(x);
                            if(!sides.get(index).isUsed[p])sideSet2.add(index);
                        }
                    }
                }
                flexibility1 = sideSet1.size() / minTrackWithT[startNode1][endNode1].get(0).trackList.size();
                flexibility2 = sideSet2.size() / minTrackWithT[startNode2][endNode2].get(0).trackList.size();
                int num =minTrackWithT[startNode2][endNode2].get(0).trackList.size()
                        - minTrackWithT[startNode1][endNode1].get(0).trackList.size();
//                int num1 = num == 0? minTrackWithT[startNode2][endNode2].get(0).trackList.size()
//                        - minTrackWithT[startNode1][endNode1].get(0).trackList.size() :num;
                int num2 = num == 0 ? flexibility1-flexibility2 : num;
                return num2;
            }
        });
        return result;
    }

    //得到轨迹上所有边的数量
    public static int getSidesNum(Track track){
        int result = 0;
        for(int i = 0;i<track.trackList.size()-1;i++){
            int start = track.trackList.get(i);
            int end = track.trackList.get(i+1);
            result += graph[start][end].sides.size();
        }
        return result;
    }
    
    //对应通道中能完成业务的Track
    public static Track getPath1(int startNode, int endNode,int p){
        Track minTrack = new Track();
        ArrayList<Track> trackList = minTrackWithT[startNode][endNode];
        trackList.sort(new Comparator<Track>() {
            @Override
            public int compare(Track o1, Track o2) {
                return o2.getFreeSideNum(p) - o1.getFreeSideNum(p);
            }
        });
        for (int i = 0; i < trackList.size(); i++) {
            Track track = trackList.get(i);
            boolean flag = true;
            for(int j = 0;j<track.trackList.size()-1;j++){
                int start = track.trackList.get(j);
                int end = track.trackList.get(j+1);
                if(graph[start][end].getSideIdWithFreeP(p) == -1){
                    flag = false;
                    break;
                }
            }
            if(flag){
                minTrack.p = p;
                minTrack.trackList = new ArrayList<>(trackList.get(i).trackList);
                break;
            }
        }
        return minTrack;
    }

    public static Track getMinCostTrack(int startNode,int endNode){
        Track minTrack = new Track();
        int minCost = Integer.MAX_VALUE;
        for(int p = 0;p<P;p++){
            Track track = getMinCostTrack(startNode,endNode,p);
            if(track.cost < minCost){
                minCost= track.cost;
                minTrack = track;
            }
        }
        return minTrack;
    }
    public static Track getMinCostTrack(int startNode,int endNode,int p){
        PriorityQueue<Node> pq = new PriorityQueue<>(new Comparator<Node>() {
            @Override
            public int compare(Node o1, Node o2) {
                return o1.costFromStart-o2.costFromStart;
            }
        });
        //visited = new boolean[N];
        pq.add(new Node(startNode,0,0));
        int[] costTo = new int[N];
        pre = new int[N];

        Arrays.fill(costTo,Integer.MAX_VALUE);
        Arrays.fill(pre,-1);

        costTo[startNode] = 0;
        Track track = new Track();
        track.trackList.add(startNode);
        while (!pq.isEmpty()){
            Node cur = pq.poll();
            int curId = cur.id;
            int curCostFromStart = cur.costFromStart;
            int curDepth = cur.depth;
            //visited[startNode] = true;

            // 到达终点，退出
            if (curId == endNode) {
                LinkedList<Integer> path = new LinkedList<>();
                printTrack(startNode, endNode, path);
                track.trackList = new ArrayList<>(path);
                track.p = p;
                track.cost = costTo[endNode];
                return track;
            }

            if (curCostFromStart > costTo[curId]) {
                // 已经有⼀条更短的路径到达 curNode 节点了
                continue;
            }

            for(int j = 0;j<graphList[curId].size();j++){
                int nextId = graphList[curId].get(j);
                int costToNext = costTo[curId] + graph[curId][nextId].getCost(p);
                if (costTo[nextId] > costToNext) {
                    // 更新 dp table
                    costTo[nextId] = costToNext;
                    // 将这个节点以及距离放⼊队列
                    pq.offer(new Node(nextId, costToNext,curDepth+1));
                    pre[nextId] = curId;
                }
            }
        }
        return null;
    }

    //region 未使用函数

    //获取两点之间所有最短路径中加边最少的路径和通道
    public static Track getPath2(int startNode, int endNode) {
        int minAddSideNum = Integer.MAX_VALUE;
        Track minTrack = new Track();
        ArrayList<Track> trackList = minTrackWithT[startNode][endNode];
        int x = trackList.get(0).trackList.size();
        for (int i = 0; i < trackList.size(); i++) {
            //if(trackList.get(i).trackList.size() > x )break;
            for (int p = 0; p < P; p++) {
                trackList.get(i).p = p;
                int addSideNum = trackList.get(i).getNeedAddSideNum();
                if (minAddSideNum > addSideNum) {
                    minAddSideNum = addSideNum;
                    minTrack.p = p;
                    minTrack.trackList = new ArrayList<>(trackList.get(i).trackList);
                }
            }
        }
        return minTrack;
    }

    //获取在不加边的情况下能够完成业务的最短Track
    public static Track getPath1(int startNode, int endNode) {
        int minSideNum = Integer.MAX_VALUE;
        Track minTrack = new Track();
        for (int p = 0; p < P; p++) {
            Track track = getMinPathWithP(startNode, endNode, p);
            int sideNum = track == null ? Integer.MAX_VALUE : track.trackList.size() - 1;
            if (minSideNum > sideNum) {
                minSideNum = sideNum;
                minTrack.trackList = new ArrayList<>(track.trackList);
                minTrack.p = p;
                //break;
            }
        }
        return minTrack;
    }

    //获取对应通道在不加边的情况下能够完成业务的Track
    public static Track getMinPathWithP(int startNode, int endNode, int p) {
        pre = new int[N];
        Track track = new Track();
        visited = new boolean[N];
        Queue<Integer> q = new LinkedList<>();
        q.add(startNode);
        visited[startNode] = true;
        while (!q.isEmpty()) {
            Integer cur = q.poll();
            if (cur == endNode) {
                LinkedList<Integer> path = new LinkedList<>();
                printTrack(startNode, endNode, path);
                track.trackList = new ArrayList<>(path);
                track.p = p;
                return track;
            }
            for (int j = 0; j < graphList[cur].size(); j++) {
                int next = graphList[cur].get(j);
                if (!visited[next] && graph[cur][next].getSideIdWithFreeP(p) != -1) {
                    q.add(next);
                    visited[next] = true;
                    pre[next] = cur;
                }
            }
        }
        return null;
    }

    // endregion

    public static ArrayList<Integer>[] preList;

    //获取两点间的所有的最短路径
    public static ArrayList<Track> getMinPath(int startNode, int endNode) {
        visited = new boolean[N];
        preList = new ArrayList[N];
        for (int i = 0; i < N; i++) {
            preList[i] = new ArrayList<>();
        }
        Queue<Integer> q = new LinkedList<>();
        q.add(startNode);

        while (!q.isEmpty()) {
            Integer cur = q.poll();
            visited[cur] = true;
            if (cur == endNode) {
                ArrayList<Track> res = new ArrayList<>();
                LinkedList<Integer> path = new LinkedList<>();
                getPath(startNode, endNode, path, res);
                return res;
            }
            for (int j = 0; j < graphList[cur].size(); j++) {
                int next = graphList[cur].get(j);
                if (!visited[next] && !preList[next].contains(cur) ) {
                    q.add(next);
                    preList[next].add(cur);
                }
            }
        }
        return null;
    }

    //根据preList获取两点之间的所有最短路径
    static int depth = 0;
    public static void getPath(int startNode, int endNode, LinkedList<Integer> track, ArrayList<Track> res) {
        track.addFirst(endNode);
        if(!res.isEmpty() && track.size() > res.get(0).trackList.size())return;
        if (startNode == endNode) {
            res.add(new Track(track));
            return;
        }
        for (int i = 0; i < preList[endNode].size(); i++) {
            int next = preList[endNode].get(i);
            getPath(startNode, next, track, res);
            track.removeFirst();
        }
    }

    //对轨迹进行加边处理
    public static void addSide(Track track,int t){
        ArrayList<Integer> sideList = track.getSideList();
        for (int j = 0; j < sideList.size(); j++) {
            int sideId = sideList.get(j);
            if (sideId == -1) {
                int start = track.trackList.get(j);
                int end = track.trackList.get(j + 1);
                M++;
                sides.add(new Side(M - 1, start, end, graph[start][end].getMinDis()));
                addSide.add(new int[]{start, end});
                graph[start][end].sides.add(M - 1);
                graph[end][start].sides.add(M - 1);
                businessTotal[t].addSideCost += ADD_SIDE_COST;
            }
        }
    }

    //处理业务
    public static void processBus(int t,Track track){
        //根据加边后找到的路径处理业务
        ArrayList<Integer> sideList = track.getSideList();
        for (int s = 0; s < sideList.size(); s++) {
            int sideId = sideList.get(s);
            if (businessTotal[t].remainD < sides.get(sideId).dis) {
                businessTotal[t].amplifierList.add(track.trackList.get(s));
                businessTotal[t].remainD = D;
                businessTotal[t].amplifierCost += AMPLIFIER_COST;
            }
            businessTotal[t].sideList.add(sideId);
            businessTotal[t].remainD -= sides.get(sideId).dis;

            businessTotal[t].pId = track.p;
            sides.get(sideId).isUsed[track.p] = true;
            businessTotal[t].edgeCost += EDGE_COST;
        }
        businessTotal[t].isProcess = true;
        notProcessNum--;
    }

    public static void init() {
        Scanner cin = new Scanner(System.in);
        N = cin.nextInt();
        M = cin.nextInt();
        T = cin.nextInt();
        P = cin.nextInt();
        D = cin.nextInt();

        notProcessNum = T;
        sideArray = new int[M][3];
        for (int x = 0; x < M; x++) {
            sideArray[x][0] = cin.nextInt();
            sideArray[x][1] = cin.nextInt();
            sideArray[x][2] = cin.nextInt();
        }

        //初始化邻接矩阵
        graph = new Passage[N][N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                graph[i][j] = new Passage();
            }
        }
        ArrayList<int[]> sideArray1 = new ArrayList<>();
        for (int i = 0; i < sideArray.length; i++) {
            int start = sideArray[i][0];
            int end = sideArray[i][1];

            //去重，用于创建邻接表
            if (i == 0) sideArray1.add(sideArray[i]);
            else if (sideArray1.get(sideArray1.size() - 1)[0] != start || sideArray1.get(sideArray1.size() - 1)[1] != end) {
                sideArray1.add(sideArray[i]);
            }

            Side side = new Side(i, start, end, sideArray[i][2]);
            sides.add(side);
            graph[start][end].addSide(i);
            graph[start][end].startNode = start;
            graph[start][end].endNode = end;
            graph[end][start].addSide(i);
            graph[end][start].startNode = end;
            graph[end][start].endNode = start;
        }

        //初始化节点间的邻接表
        graphList = new ArrayList[N];
        for (int i = 0; i < N; i++) {
            graphList[i] = new ArrayList<>();
        }
        for (int i = 0; i < sideArray1.size(); i++) {
            int start = sideArray1.get(i)[0];
            int end = sideArray1.get(i)[1];
            graphList[start].add(end);
            graphList[end].add(start);
        }

        //初始化业务
        businessTotal = new Business[T];
        for (int x = 0; x < T; x++) {
            int startNode = cin.nextInt();
            int endNode = cin.nextInt();
            businessTotal[x] = new Business(x, startNode, endNode);
        }

        //初始化前序节点，用于记录通过的节点从而获取路径
        preList = new ArrayList[N];
        for (int i = 0; i < N; i++) {
            preList[i] = new ArrayList<>();
        }

        //记录起止节点间的所有最短路径
        minTrackWithT = new ArrayList[N][N];
        for(int i = 0;i<T;i++){
            int start = businessTotal[i].startNode;
            int end = businessTotal[i].endNode;

            if(minTrackWithT[start][end] == null){
                if(minTrackWithT[end][start] == null){
                    ArrayList<Track> tracks = getMinPath(start,end);
                    int minSize = Integer.MAX_VALUE;
                    for(Track track : tracks){
                        if(track.trackList.size() < minSize)minSize = track.trackList.size();
                    }
                    final int min = minSize;
                    ArrayList<Track> collect =
                            (ArrayList<Track>) tracks.stream().filter(track -> track.trackList.size() == min)
                                    .collect(Collectors.toList());
                    minTrackWithT[start][end] = collect;
                }
                else{
                    ArrayList<Track> tracks = minTrackWithT[end][start];
                    ArrayList<Track> tracks1 = new ArrayList<>();
                    for(Track track:tracks){
                        LinkedList<Integer> list = new LinkedList<>(track.trackList);
                        Collections.reverse(list);
                        tracks1.add(new Track(list));
                    }
                    minTrackWithT[start][end] = tracks1;
                }
            }

            //每组路径按 轨迹长度升序，按 总边数/轨迹长度 降序
            Collections.sort(minTrackWithT[start][end], new Comparator<Track>() {
                @Override
                public int compare(Track o1, Track o2) {
                    int sideNum1 = 0;
                    int sideNum2 = 0;
                    for(int i = 0;i<o1.trackList.size()-1;i++){
                        int start = o1.trackList.get(i);
                        int end = o1.trackList.get(i+1);
                        sideNum1 += graph[start][end].sides.size();
                    }
                    for(int i = 0;i<o2.trackList.size()-1;i++){
                        int start = o2.trackList.get(i);
                        int end = o2.trackList.get(i+1);
                        sideNum2 += graph[start][end].sides.size();
                    }
                    double s1 = sideNum1*1.0/o1.trackList.size();
                    double s2 = sideNum2*1.0/o2.trackList.size();

                    int num = Double.compare(s2, s1);
                    return num;
                }
            });
        }

        TreeMap<String,ArrayList<Integer>> tm = new TreeMap<>();
        for(int i = 0;i<T;i++){
            Business business = businessTotal[i];
            int max = Math.max(business.startNode, business.endNode);
            int min = Math.min(business.startNode, business.endNode);
            String s = min + " " + max;
            tm.computeIfAbsent(s, k -> new ArrayList<>());
            tm.get(s).add(i);
        }

/*        for(int i = 0;i<T;i++){
            businessTotal[i].num = tm.get(businessTotal[i].startNode+" "+businessTotal[i].endNode).size();
        }*/

        entryList = new ArrayList<>(tm.entrySet());

        entryList.sort(new Comparator<Map.Entry<String, ArrayList<Integer>>>() {
            @Override
            public int compare(Map.Entry<String, ArrayList<Integer>> o1, Map.Entry<String, ArrayList<Integer>> o2) {
                int startNode1 = businessTotal[o1.getValue().get(0)].startNode;
                int startNode2 = businessTotal[o2.getValue().get(0)].startNode;
                int endNode1 = businessTotal[o1.getValue().get(0)].endNode;
                int endNode2 = businessTotal[o2.getValue().get(0)].endNode;
                int flexibility1 = 0;
                int flexibility2 = 0;
                for(int i = 0;i<minTrackWithT[startNode1][endNode1].size();i++){
                    Track track = minTrackWithT[startNode1][endNode1].get(i);
                    flexibility1+= getSidesNum(track) / track.trackList.size();
                }
                for(int i = 0;i<minTrackWithT[startNode2][endNode2].size();i++){
                    Track track = minTrackWithT[startNode2][endNode2].get(i);
                    flexibility2+= getSidesNum(track) / track.trackList.size();
                }
//                int sumStart1 = 0;
//                int sumStart2 = 0;
//                int sumEnd1 = 0;
//                int sumEnd2 = 0;
//                int sum1 = 0;
//                int sum2 = 0;
//                for(int i = 0;i<graphList[startNode1].size();i++){
//                    int end = graphList[startNode1].get(i);
//                    sumStart1 += graph[startNode1][end].sides.size();
//                }
//                for(int i = 0;i<graphList[endNode1].size();i++){
//                    int end = graphList[endNode1].get(i);
//                    sumEnd1 += graph[endNode1][end].sides.size();
//                }
//                sum1 = Math.min(sumStart1,sumEnd1);
//
//                for(int i = 0;i<graphList[startNode2].size();i++){
//                    int end = graphList[startNode2].get(i);
//                    sumStart2 += graph[startNode2][end].sides.size();
//                }
//                for(int i = 0;i<graphList[endNode2].size();i++){
//                    int end = graphList[endNode2].get(i);
//                    sumEnd2 += graph[endNode2][end].sides.size();
//                }
//                sum2 = Math.min(sumStart2,sumEnd2);
//
//                int num = sum1- sum2;
                //int num1 =  o2.getValue().size() - o1.getValue().size();
                //int num1 = num == 0  ? flexibility2 -flexibility1 : num;
                int num =  minTrackWithT[startNode2][endNode2].get(0).trackList.size()
                        - minTrackWithT[startNode1][endNode1].get(0).trackList.size();
                int num1 = num ==  0? o2.getValue().size() - o1.getValue().size() : num;
                int num2 = num1 ==  0? flexibility2- flexibility1 : num1;
                //int num3 = num2 == 0? flexibility2 -flexibility1 : num2;
                return num2;
            }
        });
    }

    public static void output(){
        System.out.println(addSide.size());
        for (int i = 0; i < addSide.size(); i++) {
            System.out.println(addSide.get(i)[0] + " " + addSide.get(i)[1]);
        }
        for (int i = 0; i < T; i++) {
            businessTotal[i].print();
        }
    }
    public static void printTrack(int start, int end, LinkedList<Integer> track) {
        track.addFirst(end);
        if (start == end) return;
        printTrack(start, pre[end], track);
    }
}

class Business {
    int id;
    boolean isProcess;
    int startNode;
    int endNode;

    int num;
    int pId = -1;

    int remainD = Main.D;

    int addSideCost;
    int amplifierCost;
    int edgeCost;

    LinkedList<Integer> sideList = new LinkedList<>();
    LinkedList<Integer> amplifierList = new LinkedList<>();

    public Business(int id, int startNode, int endNode) {
        this.id = id;
        this.startNode = startNode;
        this.endNode = endNode;
    }

    public void print() {
        if(pId == -1)
            return;
        System.out.print(pId + " ");
        System.out.print(sideList.size() + " ");
        System.out.print(amplifierList.size() + " ");
        for (int i : sideList) {
            System.out.print(i + " ");
        }
        for (int i = 0; i < amplifierList.size(); i++) {
            if (i == amplifierList.size() - 1) System.out.println(amplifierList.get(i));
            else System.out.print(amplifierList.get(i) + " ");
        }
    }
}

class Passage {
    //两点间的所有边
    ArrayList<Integer> sides = new ArrayList<>();
    int remainPNum;
    int startNode;
    int endNode;

    int minDis;

    int d;

    int cost;

    //根据通道找到可以通过的边id
    public int getSideIdWithFreeP(int p) {
        for (Integer sideId : sides) {
            if (!Main.sides.get(sideId).isUsed[p]) {
                return sideId;
            }
        }
        return -1;
    }

    public int getFreeSideNum(int p) {
        int result = 0;
        for (Integer sideId : sides) {
            if (!Main.sides.get(sideId).isUsed[p]) {
                result++;
            }
        }
        return result;
    }

//    public int getCost(){
//
//    }

    public int getD(){
        int result = 0;
        for(int i = 0;i<Main.graphList[startNode].size();i++){
            int end = Main.graphList[startNode].get(i);
            result += Main.graph[startNode][end].sides.size();
        }
        return result;
    }

    public int getMinDis() {
        int min = Integer.MAX_VALUE;
        for (Integer id : sides) {
            if (min > Main.sides.get(id).dis) {
                min = Main.sides.get(id).dis;
            }
        }
        return min;
    }

    public void addSide(Integer sideId) {
        this.sides.add(sideId);
        remainPNum += Main.P;
    }
    public int getCost(int p){
        int num = 0;
        for (Integer sideId : sides) {
            if (!Main.sides.get(sideId).isUsed[p]) {
                num++;
            }
        }
        return num == 0 ? Main.ADD_SIDE_COST + Main.THROUGH_EDGE_COST : Main.THROUGH_EDGE_COST / num;
    }
}

class Side {
    public int id;
    int dis;
    boolean isAdd;
    boolean[] isUsed = new boolean[Main.P];

    int startNode;
    int endNode;

    int remainPNum = Main.P;

    public Side(int id, int startNode, int endNode, int dis) {
        this.id = id;
        this.dis = dis;
        this.startNode = startNode;
        this.endNode = endNode;
    }
}

class Track {
    //轨迹的节点list
    ArrayList<Integer> trackList = new ArrayList<>();

    int cost;
    int p;

    int x ;
    //边list
    ArrayList<Integer> sideList = new ArrayList<>();
    int[] needAddSideNum = new int[Main.P];

    public Track() {
    }

    public Track(List<Integer> trackList) {
        this.trackList = new ArrayList<>(trackList);
    }

    //根据trackList和p获取sideList
    public ArrayList<Integer> getSideList() {
        sideList = new ArrayList<>();
        for (int i = 0; i < trackList.size() - 1; i++) {
            int start = trackList.get(i);
            int end = trackList.get(i + 1);

            int sideId = Main.graph[start][end].getSideIdWithFreeP(p);
            sideList.add(sideId);
        }
        return sideList;
    }


    public int getFreeSideNum(int p) {
        int result = 0;
        //sideList = new ArrayList<>();
        for (int j = 0; j < trackList.size() - 1; j++) {
            int start = trackList.get(j);
            int end = trackList.get(j + 1);
            int num = Main.graph[start][end].getFreeSideNum(p);
            //sideList.add(sideId);
            result += num ;
        }
        x= result;
        return result;
    }

    //当前trackList需要增加的边数
    public int getNeedAddSideNum(){
        int needAddSideNum = 0;
        //sideList = new ArrayList<>();
        for (int j = 0; j < trackList.size() - 1; j++) {
            int start = trackList.get(j);
            int end = trackList.get(j + 1);
            int sideId = Main.graph[start][end].getSideIdWithFreeP(p);
            //sideList.add(sideId);
            needAddSideNum += sideId == -1 ? 1 : 0;
        }
        this.needAddSideNum[p] = needAddSideNum;
        return this.needAddSideNum[p];
    }
}

class Node{
    int id;
    int costFromStart;
    int depth;

    public Node() {
    }

    public Node(int id, int costFromStart, int depth) {
        this.id = id;
        this.costFromStart = costFromStart;
        this.depth = depth;
    }
}