import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

/**
 * @author qzx
 * @create 2023-05-18 17:47
 * @function
 */
public class Solution {
    public static void main(String[] args) {
        ArrayList<Business> list = new ArrayList<>();
        for(int i = 0;i<10000;i++){
            list.add(new Business(10000-i,10000-i,1));
        }
        long l = System.currentTimeMillis();
        list.sort(new Comparator<Business>() {
            @Override
            public int compare(Business o1, Business o2) {
                int num =o1.id-o2.id;
                return num == 0? o1.startNode-o2.startNode : num;
            }
        });
        long l1 = System.currentTimeMillis();
        System.out.println(l1-l);
    }
}
